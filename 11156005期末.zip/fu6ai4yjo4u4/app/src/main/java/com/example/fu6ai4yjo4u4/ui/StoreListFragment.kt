package com.example.fu6ai4yjo4u4.ui

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.setFragmentResultListener
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.fu6ai4yjo4u4.R
import com.example.fu6ai4yjo4u4.viewmodel.StoreViewModel
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar

class StoreListFragment : Fragment(R.layout.fragment_store_list) {
    private lateinit var viewModel: StoreViewModel

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel = ViewModelProvider(requireActivity()).get(StoreViewModel::class.java)

        val recyclerView = view.findViewById<RecyclerView>(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(requireContext()) // <--- 必加這行
        val fabAdd = view.findViewById<FloatingActionButton>(R.id.fab_add)
        val adapter = StoreAdapter { store ->
            val bundle = Bundle().apply { putLong("storeId", store.id) }
            findNavController().navigate(
                R.id.action_storeListFragment_to_storeEditFragment,
                bundle
            )
        }
        adapter.onRatingChanged = { store ->
            viewModel.updateStore(store)
        }
        recyclerView.adapter = adapter

        viewModel.stores.observe(viewLifecycleOwner) {
            adapter.submitList(it)
        }

        fabAdd.setOnClickListener {
            findNavController().navigate(R.id.action_storeListFragment_to_storeEditFragment)
        }

        // 監聽從 StoreEditFragment 回來的結果，顯示 Snackbar
        setFragmentResultListener("store_edit_result") { _, bundle ->
            val result = bundle.getString("result")
            if (!result.isNullOrEmpty()) {
                Snackbar.make(view, result, Snackbar.LENGTH_SHORT).show()
            }
        }
    }
}
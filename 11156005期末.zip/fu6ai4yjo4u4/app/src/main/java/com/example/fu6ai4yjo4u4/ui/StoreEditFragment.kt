package com.example.fu6ai4yjo4u4.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.fragment.app.setFragmentResult
import com.example.fu6ai4yjo4u4.R
import com.example.fu6ai4yjo4u4.model.Store
import com.example.fu6ai4yjo4u4.viewmodel.StoreViewModel
import com.google.android.material.snackbar.Snackbar

class StoreEditFragment : Fragment(R.layout.fragment_store_edit) {
    private lateinit var viewModel: StoreViewModel
    private var editingStoreId: Long? = null
    private var imageUri: String? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel = ViewModelProvider(requireActivity()).get(StoreViewModel::class.java)
        editingStoreId = arguments?.getLong("storeId")

        val et_name = view.findViewById<EditText>(R.id.et_name)
        val et_phone = view.findViewById<EditText>(R.id.et_phone)
        val et_address = view.findViewById<EditText>(R.id.et_address)
        val btn_save = view.findViewById<Button>(R.id.btn_save)
        val btn_cancel = view.findViewById<Button>(R.id.btn_cancel)
        val img_store = view.findViewById<ImageView>(R.id.img_store)
        val btn_upload = view.findViewById<Button>(R.id.btn_upload)

        if (editingStoreId != null) {
            val store = viewModel.getStoreById(editingStoreId!!)
            // 填入資料
            et_name.setText(store?.name)
            et_phone.setText(store?.phone)
            et_address.setText(store?.address)
            imageUri = store?.imageUri
            if (!imageUri.isNullOrEmpty()) {
                img_store.setImageURI(Uri.parse(imageUri))
            }
        }

        btn_cancel.setOnClickListener {
            findNavController().popBackStack()
        }

        btn_upload.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            startActivityForResult(intent, 1001)
        }

        btn_save.setOnClickListener {
            val name = et_name.text.toString()
            val phone = et_phone.text.toString()
            val address = et_address.text.toString()

            if (name.isBlank() || phone.isBlank() || address.isBlank()) {
                Snackbar.make(view, "請填寫所有欄位", Snackbar.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (editingStoreId != null) {
                val store = Store(editingStoreId!!, name, phone, address, 0f, imageUri)
                viewModel.updateStore(store)
                setFragmentResult("store_edit_result", Bundle().apply {
                    putString("result", "更新成功")
                })
            } else {
                val store = Store(0L, name, phone, address, 0f, imageUri)
                viewModel.addStore(store)
                setFragmentResult("store_edit_result", Bundle().apply {
                    putString("result", "新增成功")
                })
            }
            findNavController().popBackStack()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001 && resultCode == Activity.RESULT_OK) {
            val uri = data?.data
            view?.findViewById<ImageView>(R.id.img_store)?.setImageURI(uri)
            imageUri = uri?.toString()
        }
    }
}
package com.example.fu6ai4yjo4u4.model

data class Store(
    var id: Long = 0L,
    var name: String,
    var phone: String,
    var address: String,
    var rating: Float,
    var imageUri: String? = null // 新增欄位：照片 Uri
)

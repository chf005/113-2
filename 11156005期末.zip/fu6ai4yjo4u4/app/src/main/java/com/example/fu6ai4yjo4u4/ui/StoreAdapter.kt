package com.example.fu6ai4yjo4u4.ui

import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.fu6ai4yjo4u4.R
import com.example.fu6ai4yjo4u4.model.Store

class StoreAdapter(
    private val onItemClick: (Store) -> Unit
) : ListAdapter<Store, StoreAdapter.StoreViewHolder>(StoreDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StoreViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_store, parent, false)
        return StoreViewHolder(view)
    }

    override fun onBindViewHolder(holder: StoreViewHolder, position: Int) {
        val store = getItem(position)
        holder.bind(store)
        holder.itemView.setOnClickListener { onItemClick(store) }
        holder.phoneView.setOnClickListener {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${store.phone}"))
            it.context.startActivity(intent)
        }
        holder.ratingBar.setOnRatingBarChangeListener { _, rating, fromUser ->
            if (fromUser) {
                store.rating = rating
                onRatingChanged?.invoke(store)
            }
        }
    }

    class StoreViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val phoneView: TextView = itemView.findViewById(R.id.tv_phone)
        val ratingBar: RatingBar = itemView.findViewById(R.id.ratingBar)
        val imgStore: ImageView = itemView.findViewById(R.id.img_store)
        fun bind(store: Store) {
            itemView.findViewById<TextView>(R.id.tv_name).text = store.name
            phoneView.text = store.phone
            itemView.findViewById<TextView>(R.id.tv_address).text = store.address
            ratingBar.rating = store.rating
            // 使用 Android 內建圖示作為預設圖片
            imgStore.setImageResource(android.R.drawable.ic_menu_gallery)
            if (!store.imageUri.isNullOrEmpty()) {
                imgStore.setImageURI(Uri.parse(store.imageUri))
            }
        }
    }

    var onRatingChanged: ((Store) -> Unit)? = null

    class StoreDiffCallback : DiffUtil.ItemCallback<Store>() {
        override fun areItemsTheSame(oldItem: Store, newItem: Store): Boolean {
            return oldItem.id == newItem.id
        }
        override fun areContentsTheSame(oldItem: Store, newItem: Store): Boolean {
            return oldItem == newItem
        }
    }
}
package com.example.fu6ai4yjo4u4.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.fu6ai4yjo4u4.model.Store

class StoreViewModel : ViewModel() {
    private val _stores = MutableLiveData<List<Store>>(emptyList())
    val stores: LiveData<List<Store>> = _stores

    private var nextId = 1L

    fun addStore(store: Store) {
        store.id = nextId++
        val newList = _stores.value.orEmpty().toMutableList()
        newList.add(store)
        _stores.value = newList
    }

    fun updateStore(store: Store) {
        val newList = _stores.value.orEmpty().toMutableList()
        val idx = newList.indexOfFirst { it.id == store.id }
        if (idx >= 0) {
            newList[idx] = store
            _stores.value = newList
        }
    }

    fun getStoreById(id: Long): Store? {
        return _stores.value?.find { it.id == id }
    }
}
